package com.hcl.tokbox;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import com.opentok.MediaMode;
import com.opentok.OpenTok;
import com.opentok.Role;
import com.opentok.Session;
import com.opentok.SessionProperties;
import com.opentok.TokenOptions;
import com.opentok.exception.OpenTokException;

@Path("/getSession")
public class GetSession {

	@GET
	@Produces("application/json")
	public Response createOpenTokSession() {
		String mSessionId = "1_MX40NTYyMDMzMn5-MTQ2ODkxMTY4NzQ5OH5QanFpSHVxYnNQNnVHMzVBSG5tZVBBWEF-fg";
		int apiKey = 45620332; //Please use your API KEY here
		String apiSecret = "b01364146ede95817bd20c4c350b83b7ca984486";
		OpenTok opentok = new OpenTok(apiKey, apiSecret);
		Session session = null;
		String token = "";
		try {
			String sessionId = mSessionId;
			if (sessionId == null || sessionId.equalsIgnoreCase("")) {
				session = opentok.createSession(new SessionProperties.Builder().mediaMode(MediaMode.ROUTED).build());
				sessionId = session.getSessionId();
				System.out.println("Hello SessionID" + sessionId);
				mSessionId = sessionId;
			}
			token = opentok.generateToken(sessionId, new TokenOptions.Builder().role(Role.PUBLISHER)
					.expireTime((System.currentTimeMillis() / 1000L) + (3 * 60 * 60)).build());
			System.out.println("hello token" + token);
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("Session", sessionId);
			jsonObject.put("token", token);
			String result = jsonObject.toString();
			return Response.status(200).entity(result).build();

		} catch (OpenTokException e1) {
			e1.printStackTrace();
			System.out.println("Hello Exception" + e1.getMessage());
			return Response.status(404).entity("Not able to generate").build();

		}
	}

}
